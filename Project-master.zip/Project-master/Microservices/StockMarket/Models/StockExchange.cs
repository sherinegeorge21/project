﻿using System;
using System.Collections.Generic;

namespace StockMarket.Models
{
    public partial class StockExchange
    {
        public decimal SeId { get; set; }
        public string StockExchange1 { get; set; }
        public string Brief { get; set; }
        public string Address { get; set; }
        public string Remarks { get; set; }
    }
}

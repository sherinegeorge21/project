export class Company {
        companyId: number;
        companyName: String;
        turnover: number;
        ceo: string;
        boardOfDirectors: string;
        listedinStockExchange: number;
        sector: string;
        briefWriteUp: string;
        companyStockCode: number;
      }

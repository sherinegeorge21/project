export class Stocks {
}

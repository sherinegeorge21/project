import { DecimalPipe } from '@angular/common';

export class User {
    Id: number;
    Username : string;
    Password : string;
         UserType : string;
      Email : string;
      MobileNumber: number;
        Confirmed : string;
}
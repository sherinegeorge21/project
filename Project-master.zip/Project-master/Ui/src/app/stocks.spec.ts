import { Stocks } from './stocks';

describe('Stocks', () => {
  it('should create an instance', () => {
    expect(new Stocks()).toBeTruthy();
  });
});

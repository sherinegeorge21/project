import { StockExchanges } from './stock-exchanges';

describe('StockExchanges', () => {
  it('should create an instance', () => {
    expect(new StockExchanges()).toBeTruthy();
  });
});

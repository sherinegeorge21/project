export class StockExchanges {
    Seid : number ;
    StockExchange  : string;
    Brief : string;
    Address : string;
    Remarks : string; 
}

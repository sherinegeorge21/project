import { IPOdetails } from './ipodetails';

describe('IPOdetails', () => {
  it('should create an instance', () => {
    expect(new IPOdetails()).toBeTruthy();
  });
});
